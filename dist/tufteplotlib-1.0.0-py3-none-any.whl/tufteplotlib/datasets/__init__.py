from .anscombe import anscombe

__all__ = ["anscombe"]
